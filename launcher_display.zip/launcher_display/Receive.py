import socket
import time
import serial
import serial.tools.list_ports
import string
import os

ports = list(serial.tools.list_ports.comports())
for p in ports:
    str = p[2]
    if "AL02EYKHA" in str:
        com_port = p[0]
        print com_port

os.system("start dump1090.bat")
time.sleep(4)

TCP_IP = '127.0.0.1'

TCP_PORT = 30001
BUFFER_SIZE = 1024

ser = serial.Serial(com_port)
sta = ''

while True:

		msg = ser.read(1)
		sta = sta + msg
		if msg == b'\x00':
			print('null character found')
		if msg == b';':
                        print (sta)
                        sta = sta + '\x0a'
			s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			s.connect((TCP_IP, TCP_PORT))
			s.send(sta)
			sta = ''
			s.close()
