import csv
import random
import time
import socket
from waypoint import *
from aircraft import *
import threading

TCP_IP = '127.0.0.1'
TCP_PORT = 30001
BUFFER_SIZE = 1024

#Spawn point 1
#Slightly below blackjack rd
LAT_SPAWN1 = 33.493898
LON_SPAWN1 = -88.570935

LAT_SPAWN2 = 33.452369
LON_SPAWN2 = -88.787605

OUR_LAT = LAT_SPAWN2
OUR_LON = LON_SPAWN2

#Point3
LAT3 = 33.559811
LON3 = -88.708043

OUR_MSG = '*8DAC82EC480B024D3556377E28C3;' + '\x0a'
OUR_ODD_MSG = '*8DAC82EC480B05EE0FD47E7EC6F6;' + '\x0a'

origin = (LAT_SPAWN1, LON_SPAWN1)
destination = (LAT_SPAWN2, LON_SPAWN2)
point3 = (LAT3, LON3)
ac = Aircraft(Waypoint(origin), 3000, Waypoint(destination))
ac.setAltitude(1000)
#ac.setSpeed(500)
point_count = 0
while True:
    if ac.update(int(round(time.time() * 1000))):
        if point_count == 0:
            ac.addWaypoint(Waypoint(point3))
            point_count = point_count + 1
        elif point_count == 1:
            ac.addWaypoint(Waypoint(origin))
            point_count = point_count + 1
        elif point_count == 2:
            ac.addWaypoint(Waypoint(destination))
            ac.setAltitude(1000)
            point_count = 0
    msg = ac.form_airborne_position_msg() + '\x0a'
    msg1 = ac.form_aircraft_velocity_msg() + '\x0a'
    print (msg)
    print (msg1)
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((TCP_IP, TCP_PORT))
    s.send(msg.encode('UTF-8'))
    time.sleep(1)
    s.send(msg1.encode('UTF-8'))
    s.send(OUR_MSG.encode('UTF-8'))
    s.send(OUR_ODD_MSG.encode('UTF-8'))
    s.close()
        
