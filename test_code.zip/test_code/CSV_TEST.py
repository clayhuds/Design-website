import csv
import random
import time
import socket
from waypoint import *
from aircraft import *
import threading

TCP_IP = '127.0.0.1'
TCP_PORT = 30001
BUFFER_SIZE = 1024


millis = int(round(time.time() * 1000))
#random.randint(1,85) % 85
LAT_INDEX = 2
LON_INDEX = 3
wp_list = []
with open('../airports/airnew.csv', newline='') as f:
    reader = csv.reader(f)
    for row in reader:
        wp_list.append((float(row[LAT_INDEX]), float(row[LON_INDEX])))
#print (wp_list)
##Create plane flight paths
i = 0
origin = []
destination = []
flight_paths = []
planes = []
for i in range(0, 5):
    rand = random.randint(1, len(wp_list)) % len(wp_list)
    #print ('Random number generated is %d' % (rand))
    origin.append(Waypoint(wp_list[rand]))
    #print (origin[i].getLatLonDegrees())
    destination.append(\
        Waypoint(wp_list[random.randint(rand, len(wp_list)) % len(wp_list)]))
    #print (destination[i].getLatLonDegrees())
    planes.append(Aircraft(origin[i], 200, destination[i]))
    #flight_paths.append((origin[i], destination[i]))

def cbf(ac):
    while True:
        ac.update(int(round(time.time() * 1000)))
        msg = ac.form_airborne_position_msg() + '\x0a'
        msg1 = ac.form_aircraft_velocity_msg() + '\x0a'
        print (msg)
        print (msg1)
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((TCP_IP, TCP_PORT))
        s.send(msg.encode('UTF-8'))
        time.sleep(1)
        s.send(msg1.encode('UTF-8'))
        s.close()
threads = []
for p in planes:
    threads.append(threading.Thread(target=cbf, args=(p,)))
for t in threads:
    t.start()

#threading.Thread(target=cbf, args = (ac))

    
