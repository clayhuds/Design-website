#
#
# PMTK_API_SET_NMEA_OUTPUT
RMC_ONLY = "$PMTK314,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0*29\r\n"
GGA_RMC = "$PMTK314,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0*0C\r\n"
UPDATE_1HZ = "$PMTK220,1000*1F\r\n"
UPDATE_5HZ = "$PMTK220, 200*2C\r\n"
UPDATE_10HZ = "$PMTK220,100*2F\r\n"

def set_update_1HZ():
    """Set update rate to 1Hz."""
    ser.write(UPDATE_1HZ)

def set_update_5HZ():
    """Set update rate to 5Hz."""
    ser.write(UPDATE_5HZ)

def set_update_10HZ():
    """Set update rate to 10Hz."""
    ser.write(UPDATE_10HZ)


def nmea_rmc_only():
    """Outputs NMEA sentence for RMC only."""
    ser.write(RMC_ONLY)

def nmea_gga_rmc():
    """Outputs NMEA sentence for RMC and GGA."""
    ser.write(GGA_RMC)

def get_altitude(str):
    str = str.split(',')
    if str[0] == "$GPGGA":
        alt = int(round(float((str[9]))))
        return alt
        

def get_lat(str):
    """Gets the latitude and longitude from the NMEA sentence"""
    str = str.split(',')
    if str[0] == "$GPRMC":
	if str[2] == 'A':
        	lat = str[3]
        	lat = float(lat[0:2]) + float(lat[2:9]) / 60
        	if str[4] == 'S':
            		lat = lat * -1
        	return lat
	else:
		return None


def get_lon(str):
    """Gets the latitude and longitude from the NMEA sentence"""
    str = str.split(',')
    if str[0] == "$GPRMC":
	if str[2] == 'A':
        	lon = str[5]
        	lon = float(lon[0:3]) + float(lon[3:10]) / 60
        	if str[6] == 'W':
            		lon = lon * -1
        	return lon
	else:
		return None

def get_velocity(str):
    """Returns the tuple (speed, heading) from the NMEA sentence"""
    str = str.split(',')
    if str[0] == "$GPRMC":
	if str[2] == 'A':
        	speed = float(str[7])
        	heading = float(str[8])
                return (speed, heading)
	else:
		return None

    
                                    
    


