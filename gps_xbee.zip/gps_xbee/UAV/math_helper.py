import math
import cmath

# https://github.com/junzis/pyModeS/blob/master/pyModeS/util.py
# The link above is the source for some of the code in this file.
# the polynominal generattor code for CRC
GENERATOR = "1111111111111010000001001"

def convertVelocityToCartesian_x(velocity, heading):
    
    return int(round(velocity * math.sin(math.radians(heading))))

def convertVelocityToCartesian_y(velocity, heading):

    return int(round(velocity * math.cos(math.radians(heading))))

def int2bin(int_num, num_of_bits):
    """Converts integer to binary string, with zero fillings. """
    binstr = bin(int_num)[2:].zfill(num_of_bits)
    return binstr

def hex2bin(hexstr):
    """Convert a hexdecimal string to binary string, with zero fillings. """
    scale = 16
    num_of_bits = len(hexstr) * math.log(scale, 2)
    binstr = bin(int(hexstr, scale))[2:].zfill(int(num_of_bits))
    return binstr

def bin2hex(binstr):
    """Convert a binary string to a hexdecimal string. """
    n = 4
    hexstr = ''
    binstr = [binstr[i:i+n] for i in range(0, len(binstr), n)]
    for i in range(0, len(binstr)):
        tmp = bin2int(binstr[i])
        hexstr = hexstr + int2hex(tmp, 1).upper()

    return hexstr
        #for j in range(0, len(binstr[i])):
            
        
def int2hex(int_num, num_of_bytes):
    """Convert an integer string to hexdecimal string, with zero fillings. """
    hexstr = hex(int_num)[2:].zfill(num_of_bytes)
    return hexstr

def int2hexADSB(int_num):
    """Convert an integer string to hexdecimal string, with zero fillings. """
    hexstr = hex(int_num)[2:30].zfill(28)
    return hexstr


def bin2int(binstr):
    """Convert a binary string to integer. """
    return int(binstr, 2)


def hex2int(hexstr):
    """Convert a hexdecimal string to integer. """
    return int(hexstr, 16)


def df(msg):
    """Decode Downlink Format vaule, bits 1 to 5."""
    msgbin = hex2bin(msg)
    return bin2int(msgbin[0:5])


def crc(msg, encode=False):
    """Mode-S Cyclic Redundancy Check
    Detect if bit error occurs in the Mode-S message
    Args:
        msg (string): 28 bytes hexadecimal message string
        encode (bool): True to encode the date only and return the checksum
    Returns:
        string: message checksum, or partity bits (encoder)
    """

    msgbin = list(hex2bin(msg))

    if encode:
        msgbin[-24:] = ['0'] * 24

    # loop all bits, except last 24 piraty bits
    for i in range(len(msgbin)-24):
        # if 1, perform modulo 2 multiplication,
        if msgbin[i] == '1':
            for j in range(len(GENERATOR)):
                # modulo 2 multiplication = XOR
                msgbin[i+j] = str((int(msgbin[i+j]) ^ int(GENERATOR[j])))

    # last 24 bits
    reminder = ''.join(msgbin[-24:])
    return reminder


def floor(x):
    """ Mode-S floor function
        Defined as the greatest integer value k, such that k <= x
        eg.: floor(3.6) = 3, while floor(-3.6) = -4
    """
    return int(math.floor(x))


# Returns XOR of 'a' and 'b'
# (both of same length)
def xor(a, b):
 
    # initialize result
    result = []
 
    # Traverse all bits, if bits are
    # same, then XOR is 0, else 1
    for i in range(1, len(b)):
        if a[i] == b[i]:
            result.append('0')
        else:
            result.append('1')
 
    return ''.join(result)
 
 
# Performs Modulo-2 division
def mod2div(divident, divisor):
 
    # Number of bits to be XORed at a time.
    pick = len(divisor)
 
    # Slicing the divident to appropriate
    # length for particular step
    tmp = divident[0 : pick]
 
    while pick < len(divident):
 
        if tmp[0] == '1':
 
            # replace the divident by the result
            # of XOR and pull 1 bit down
            tmp = xor(divisor, tmp) + divident[pick]
 
        else:   # If leftmost bit is '0'
            # If the leftmost bit of the dividend (or the
            # part used in each step) is 0, the step cannot
            # use the regular divisor; we need to use an
            # all-0s divisor.
            tmp = xor('0'*pick, tmp) + divident[pick]
 
        # increment pick to move further
        pick += 1
 
    # For the last n bits, we have to carry it out
    # normally as increased value of pick will cause
    # Index Out of Bounds.
    if tmp[0] == '1':
        tmp = xor(divisor, tmp)
    else:
        tmp = xor('0'*pick, tmp)
 
    checkword = tmp
    return checkword
 
# Function used at the sender side to encode
# data by appending remainder of modular divison
# at the end of data.
def encodeData(data, key):
 
    l_key = len(key)
 
    # Appends n-1 zeroes at end of data
    appended_data = data + '0'*(l_key-1)
    remainder = mod2div(appended_data, key)
 
    # Append remainder in the original data
    codeword = data + remainder
    #print("Remainder : ", remainder)
    #print("Encoded Data (Data + Remainder) : ",
    #      codeword)
    #TODO: Document says to XOR ICAO and remainder, but this yields
    #      the expected result?.
    return bin2hex(codeword)
        
