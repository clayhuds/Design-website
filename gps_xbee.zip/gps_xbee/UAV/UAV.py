import math_helper as m
import cpr as c
#import gps_helper as g
####CONSTANTS####

#TYPECODE CONSTANTS
AIRCRAFT_IDENTIFICATION_TYPECODE = 1            #Can be a number from 1 to 4, choose 1.
SURFACE_POSITION_TYPECODE = 5                   #Can be a number from 5 to 8, choose 5.
AIRBORNE_POSITION_BARO_TYPECODE = '01001'            #Can be a number from 9 to 18, choose 10.
AIRBORNE_VELOCITY_TYPECODE = '10011'
AIRBORNE_POSITION_GNSS_HEIGHT_TYPECODE = 21     #Can be a number from 20 to 22, choose 21.
AIRBORNE_TEST_MESSAGE_TYPECODE = 23
SURFACE_SYSTEM_STATUS_TYPECODE = 24
RESERVED_TYPECODE = 26                          #Can be a number from 25 to 27, choose 26.
EXTENDED_SQUITTER_AC_STATUS_TYPECODE = 28
TARGET_STATE_AND_STATUS_TYPECODE = 29
RESERVED2_TYPECODE = 30
AIRCRAFT_OPERATION_STATUS_TYPECODE = 31

DEBUG_MODE = 0
GENERATOR = "1111111111111010000001001"
TEST_MSG = "8D451E8B99019699C00B0A"
DOWNLINK_FORMAT = '10001'
TYPECODE = '01001'
CA = '101'
ICAO = m.hex2bin('40621D') #To show hex for clarity
ICAO2 = m.hex2bin('AC82EC')
SURV_STATUS = '00'
NICSB = '0'
ALTITUDE_PLACEHOLDER = '001001001110'
ALTITUDE_BITS = 12
TIME_BITS = 1
TIME = '0'
FRAME_FLAG = '0'
AIRCRAFT_AIRBORNE = 1
PLACEHOLDER_LAT = 33.452766
PLACEHOLDER_LON = -88.794765
LAT_BITS = 17
LON_BITS = 17
data = m.hex2bin(TEST_MSG)
CRC = m.encodeData(data, GENERATOR)

#ALTITUDE
AIRCRAFT_ALTITUDE_OFFSET = 1000
AIRCRAFT_ALTITUDE_MULTIPLE_25 = 25
AIRCRAFT_ALTITUDE_MULTIPLE_100 = 100

#VELOCITY SUBTYPE1 SIZE CONSTANTS 
TC_SIZE = 5
ST_SIZE = 3
IC_SIZE = 1
RESV_A_SIZE = 1
NAC_SIZE = 3
S_WE_SIZE = 1
V_WE_SIZE = 10
S_NS_SIZE = 1
V_NS_SIZE = 10
VRSRC_SIZE = 1
S_VR_SIZE = 1
VR_SIZE = 9
RESV_B_SIZE = 2
S_DIF_SIZE = 1
DIF_SIZE = 7

#Other Velocity Constants
MSG_SUBTYPE1 = '001'

#ADSB FORMAT SIZE CONSTANTS
DOWNLINK_FORMAT_SIZE = 5
MESSAGE_SUBTYPE_SIZE = 3
ICAO_ADDRESS_SIZE = 24
DATA_FRAME_SIZE = 56
PARITY_CHECK_SIZE = 24

#Other
MSG_SUBTYPE1 = '001'
IC_FLAG = '0'
RESV_A = '1'
NAC = '000'
VRSRC = '0'
RESV_B = '00'
S_DIF = '0'
DIF = '0000000'
VRSRC_PLACEHOLDER = '0'
S_VR_PLACEHOLDER = '0'
VR_PLACEHOLDER = '000000000'




class UAV(object):
    #PRIVATE VARIABLES
    def __init__(self):
        self.lat = 0
        self.heading = 0
        self.velocity = 0
        self.lon = 0
        self.alt = 0
        self.time = 0
        self.frame_flag = 0
            
    #Public functions

    #Setters
    def set_lat(self, lat):
        self.lat = lat

    def set_lon(self, lon):
        self.lon = lon

    def set_alt(self, alt):
        self.alt = alt

    def set_velocity(self, velocity):
        self.velocity = velocity

    def set_heading(self, heading):
        self.heading = heading

    def alternate_frame(self):
        self.frame_flag = (self.frame_flag + 1) % 2


    #Getters
    def get_lat(self):
        return self.lat

    def get_lon(self):
        return self.lon

    def get_alt(self):
        return self.alt

    def get_velocity(self):
        return self.velocity

    def get_heading(self):
        return self.heading

    #Broadcast messages
    def form_airborne_position_msg(self):
        #altitude = self.get_alt() | 16
        altitude = int(((self.get_alt() + AIRCRAFT_ALTITUDE_OFFSET) / AIRCRAFT_ALTITUDE_MULTIPLE_25))
        altitude = m.int2bin(altitude, 11)
        altitude = altitude[:7] + '1' + altitude[7:]
        position = c.cpr_encode(self.lat, self.lon, int(self.frame_flag), AIRCRAFT_AIRBORNE)
        latitude = m.int2bin(position[0], LAT_BITS)
        longitude = m.int2bin(position[1], LON_BITS)
        msg = DOWNLINK_FORMAT + CA + ICAO2 + AIRBORNE_POSITION_BARO_TYPECODE + SURV_STATUS + NICSB +\
              altitude + \
              TIME + m.int2bin(self.frame_flag, 1) + latitude + longitude
        msg = '*' + m.encodeData(msg, GENERATOR) + ';'
        self.alternate_frame()
        if DEBUG_MODE == 1:
            print "Downlink format is %s" % DOWNLINK_FORMAl
            print "MSG_SUBTYPE is %s" % MSG_SUBTYPE
            print "ICAO is %s" % ICAO
            print "TYPECODE is %s" % TYPECODE
            print "SURV_STATUS is %s" % SURV_STATUS
            print "NICSB is %s " % NICSB
            print "ALTITUDE is %s " % ALTITUDE_PLACEHOLDER
            print "TIME is %s " % TIME
            print "frame_flag is %s" % frame_flag
            print "latitude is %s " % latitude
            print "longitude is %s " % longitude
            print len(msg)
        return msg

    def form_aircraft_velocity_msg(self):
        S_WE = '0'
        S_NS = '0'
        velocity_WE = m.convertVelocityToCartesian_x(self.velocity, self.heading)
        velocity_NS = m.convertVelocityToCartesian_y(self.velocity, self.heading)
        #if (0 <= self.heading <= 180): Same thing as below??
        #print (velocity_NS)
        #print (velocity_WE)
        if (velocity_WE < 0):
            S_WE = '1'
            velocity_WE = (-1 * velocity_WE) + 1
        else:
            velocity_WE = velocity_WE + 1
        #if (90 < self.heading <= 270):
        if (velocity_NS < 0):
            velocity_NS = (-1 * velocity_NS) + 1
            S_NS = '1'
        else:
            velocity_NS = velocity_NS + 1
        #print (velocity_NS)
        #print (velocity_WE)
        velocity_WE = m.int2bin(velocity_WE, V_WE_SIZE)
        velocity_NS = m.int2bin(velocity_NS, V_NS_SIZE)
        
        msg = DOWNLINK_FORMAT + CA + ICAO2 + AIRBORNE_VELOCITY_TYPECODE +\
              MSG_SUBTYPE1 + IC_FLAG + RESV_A + NAC + S_WE + velocity_WE + S_NS + velocity_NS +\
              VRSRC_PLACEHOLDER + S_VR_PLACEHOLDER + VR_PLACEHOLDER + RESV_B +\
              S_DIF + DIF

        msg = '*' + m.encodeData(msg, GENERATOR) + ';'
        return msg

    
    
