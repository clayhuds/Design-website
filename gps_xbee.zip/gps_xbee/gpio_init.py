import RPi.GPIO as GPIO

#Defining constants in case need to expand
GPS_ENABLE = 23
XB_ENABLE = 24
ENABLE_GPS = 0
DISABLE_GPS = 1
ENABLE_TRANS = 0
DISABLE_TRANS = 1

def init_gpio():
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(ENABLE, GPIO.OUT, initial=0)


def enable_gps_tx():
    GPIO.output(GPS_ENABLE, ENABLE_GPS)

def disable_gps_tx():
    GPIO.output(GPS_ENABLE, DISABLE_GPS)

def enable_trans_tx():
    GPIO.output(XB_ENABLE, ENABLE_TRANS)

