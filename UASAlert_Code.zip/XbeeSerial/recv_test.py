import time
import datetime
import serial

ser = serial.Serial('COM11')
start_time = time.time() * 1000

timeout_time = time.time()
BREAK_TIME = 60 #in seconds

bytes_read = 0

while True:
    if ser.inWaiting() >= 1:
        x = ser.inWaiting()
        bytes_read = bytes_read + x
        ser.read(x)
        
    if ((time.time() - timeout_time) > BREAK_TIME) or bytes_read == 15000:
		end_time = time.time()
		break

print "Hello"
print end_time
print bytes_read      
        
        
        
