import serial
import serial.tools.list_ports
import datetime

ok = True
while ok:
	try:
		# code to search for correct com port
		ports=list(serial.tools.list_ports.comports())
		for p in ports:
			if "xbee" in p:
				ser = serial.Serial(p)
			else:
				raise Exception("Xbee not found.")
		
	except Exception as inst:
		print("Error connecting to serial port.")
		print(inst)
		ans=input("Try again? (Y/N)  ")
		if (ans.strip(" ") == "N") or (ans.strip(" ") == "n"):
			ok = False
		
	# code to check for no connection to com port
	
	# code to run multiple com ports
	else:
		log = open("C:\\Users\\Clayton\\Documents\\Receivelog.txt","w+")

		while True:
			if ser.inWaiting() >= 30:
				log.write(str(datetime.datetime.now().time()))
				log.write(" "+ str(ser.read(ser.inWaiting()))+"\n")
				
		log.close()