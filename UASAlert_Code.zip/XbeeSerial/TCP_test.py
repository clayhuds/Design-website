import socket
import serial
import string
import time

sta = ''

TCP_IP = '127.0.0.1'
hostname = socket.gethostbyname(TCP_IP)
TCP_PORT = 30001
i=0

while True:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((hostname, TCP_PORT))
    if i%2 == 0:
	    #sta = "*8D40621D58C382D690C8AC2863A7;\x0A"
            #sta = "*8D451E8B99019699C00B0A81F36E;\x0A"
            sta = "*8dabaceb58b985e6c9b911e3040a;\x0A"
            #sta = "*8dabaceb58b985deb1bb8ce496c7;\0x0A"
    else:
	    #sta = "*8D40621D58C386435CC412692AD6;\x0A"
            #sta = "*8dabaceb58b985e6c9b911e3040a;\x0A"
            sta = "*8dabaceb58b98245893a528a4129;\0xA"
            #sta = "*8dabaceb58b985e5a9b9695255e0;\0x0A"
    s.send(sta.encode("utf-8"))
    s.close()
    sta = ''
    time.sleep(2)
    i+=1 
