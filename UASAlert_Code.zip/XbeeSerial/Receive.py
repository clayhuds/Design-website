import socket
import time
import serial
import string

TCP_IP = '127.0.0.1'

TCP_PORT = 30001
BUFFER_SIZE = 1024

ser = serial.Serial('COM5')
sta = ''
while True:

		msg = ser.read(1)
		sta = sta + msg
		if msg == b'\x00':
			print('null character found')
		if msg == b';':
                        print (sta)
                        sta = sta + '\x0a'
			s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			s.connect((TCP_IP, TCP_PORT))
			s.send(sta)
			sta = ''
			s.close()
