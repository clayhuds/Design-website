import time
import datetime
import serial

ser = serial.Serial('COM5')
start_time = time.time() * 1000
bytes_sent = 0
for i in range (0, 100):
    bytes = ser.write("*8D451E8B99019699C00B0A81F36E;")
    bytes_sent = bytes_sent + bytes

elapsed_time = (datetime.datetime.now()).microsecond - start_time
stop_time = (time.time() * 1000) - start_time

print "Sent %d bytes" % bytes_sent
print "Time elapsed: %d milliseconds" % stop_time


bytes_read = 0
while True:
    if ser.inWaiting() > 1:
        x = ser.inWaiting())
        bytes_read = bytes_read + x
        ser.read(x)
        
        
        
