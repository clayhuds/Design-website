#Display for UAS Alert
#Author: Clayton Hudspeth
#11/25/2016
#Python 3.4

#imports
import matplotlib
import json
import sys
if sys.version_info[0] < 3:
    from Tkinter import *
else:
    from tkinter import *

from PIL import Image, ImageTk
import pyModeS as pms
import serial
import Aircraft
import math

#Receiving data via Xbees
recv = FALSE
if recv:
    port = str(input("Please input COM port in the format COM# :").strip(" "))
    ser = serial.Serial(port)
    msg = ''

    while True:
        bite = ser.read(1)
        bite.decode("utf-8")
        msg = msg + bite
        if bite == b'\x00':
            print('null character found')
        if bite == b';':
            #check to see if aircraft exists already, if not create new Aircraft object and add to array of aircrafts refreshed within 30 seconds
            msg = ''

    if pms.df(msg)!=17:
        #do something
        print("DF")
    else:
        #do something else
        print("DF")


#Useful functions
def create_circle(self, x, y, r, **kwargs):
    return self.create_oval(x-r, y-r, x+r, y+r, **kwargs)


master = Tk()
master.title("UAS Alert")
master.state("zoomed")
master.update()


#Getting size of usable screen
screen_width = master.winfo_width()
screen_height = master.winfo_height()
center_x = (screen_width*0.7)/2
center_y = screen_height/2

frame = LabelFrame(master, relief="sunken", padx=5, pady=5)
frame.pack(side="left")


canvas = Canvas(frame, bg="black", width=0.7*screen_width, height=screen_height)
canvas.pack(side="right")


#Inputting images and icons
#uav1 = PIL.Image.open("C:/Users/Clayton/Documents/Programming/Python/Scripts/UAS_ALERT_DISPLAY/uav.png")
uav = ImageTk.PhotoImage(Image.open("C:/Users/Clayton/Documents/Programming/Python/Scripts/UAS_ALERT_DISPLAY/uav.jpg"))


#Creating radius circles for display
smallest_radius = screen_height/10

create_circle(canvas, center_x, center_y, smallest_radius, width="3", outline="lime green", dash=(5, 15))
create_circle(canvas, center_x, center_y, smallest_radius*2, width="3", outline="lime green", dash=(5, 15))
create_circle(canvas, center_x, center_y, smallest_radius*3, width="3", outline="lime green", dash=(5, 15))
create_circle(canvas, center_x, center_y, smallest_radius*4, width="3", outline="lime green", dash=(5, 15))
canvas.create_image(center_x, center_y, image=uav)

#Lines for display
canvas.create_line(center_x, center_y-smallest_radius*4, center_x, (center_y+smallest_radius*4), fill="lime green")
canvas.create_line(center_x-smallest_radius*4, center_y, center_x+smallest_radius*4, center_y, fill="lime green")
canvas.create_line(center_x-(smallest_radius*4/math.sqrt(2)), center_y-(smallest_radius*4/math.sqrt(2)), center_x+(smallest_radius*4/math.sqrt(2)), center_y+(smallest_radius*4/math.sqrt(2)), fill="lime green")
canvas.create_line(center_x+(smallest_radius*4/math.sqrt(2)), center_y-(smallest_radius*4/math.sqrt(2)), center_x-(smallest_radius*4/math.sqrt(2)), center_y+(smallest_radius*4/math.sqrt(2)), fill="lime green")

#Cardinal
canvas.create_text(center_x+smallest_radius*4+5, center_y, text="E", fill="lime green", anchor="w", font="12")
canvas.create_text(center_x-smallest_radius*4-5, center_y, text="W", fill="lime green", anchor="e", font="12")
canvas.create_text(center_x, center_y+smallest_radius*4+5, text="S", fill="lime green", anchor="n", font="12")
canvas.create_text(center_x, center_y-smallest_radius*4-5, text="N", fill="lime green", anchor="s", font="12")

#Airplane data readout
readout = LabelFrame(master, width=screen_width*0.3-5, height=screen_height, relief="sunken", padx=5, pady=5, text="Aircraft Information")
readout.pack(side="right")
readout.pack_propagate(False)
sel = LabelFrame(readout, bg="white", text="Selected Aircraft", width=screen_width*0.3, height=screen_height*0.2, padx=5, pady=5)
sel.pack(side="top")
sel.pack_propagate(False)
modes = LabelFrame(readout, bg="white", text="Non ADS-B Aircraft", width=screen_width*0.3, height=screen_height*0.7, padx=5, pady=5)
modes.pack(side="bottom")
modes.pack_propagate(False)
master.mainloop()





