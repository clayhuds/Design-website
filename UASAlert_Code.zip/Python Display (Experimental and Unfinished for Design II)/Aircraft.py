#Aircraft class to score data received from airplanes
#Author: Clayton Hudspeth
#11/25/2016
#Python 3.4

import pyModeS as pms
from datetime import time

class Aircraft:
    def __init__(self, msg):
        self.df = pms.df(msg)
        self.icao = get_icao(msg)
        self.lat = get_lat(msg)
        self.lon = get_lon(msg)
        self.time = time()

    def get_icao(self, msg):
        if self.df == 17:
            return pms.adsb.icao(msg)
        else:
            return None

    #added functionality for storing odd/even messages for lat and lon
    def get_lat(self, msg):
        if self.df == 17:
            return pms.adsb.cprlat(msg)
        else:
            return None

    def get_lon(self, msg):
        if self.df == 17:
            return pms.adsb.cprlon(msg)
        else:
            return None

